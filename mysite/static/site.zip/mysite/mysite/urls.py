from django.conf.urls import patterns, include, url
from mysite.index import notFound
from mysite.index import index

urlpatterns = patterns('',
	url(r'^$', index),
    #url(r'^(\w+)$', index),
    url(r'^(\w+)/(\w+)$', index),
    url(r'^.*$', notFound),
)