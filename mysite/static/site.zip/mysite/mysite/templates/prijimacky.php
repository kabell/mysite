﻿<html>
<head>
   <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
   <title>
      Prijímačky !!!
   </title>
   <link href="dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body onload="ksp();" style="margin-left:50px; margin-right:50px" align='center'>


   <div style="font-size:50px; background-color:red" align="center" id="gh">Prijímačky sa začnú presne za <div id="cas"></div></div>
   <script>

   function get_random_color() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
     color += letters[Math.round(Math.random() * 15)];
  }
  return color;
}

var ftime=<?php
echo mktime(8,0,0,6,8,2015);
//echo time()+30;
?>
;
var curtime=
<?php
echo time();
?> ;
time=ftime-curtime;
var lok;
function ksp(){
   lok = setInterval(poc, 1000);



}

function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function poc(){

   time--;
   var days  = Math.floor(time/3600/24) ;

   var hour = Math.floor((time- days*3600*24)/3600) ;
   var min = Math.floor((time-hour*3600-days*3600*24)/60);
   var sec = (time-days*3600*24-hour*3600-min*60);

   document.getElementById("cas").innerHTML=days + " dní " + hour + " hodín " + min + " minút " + sec + " sekúnd";
   
   var newcolor=get_random_color();
   document.getElementById("gh").style.backgroundColor=newcolor;
   var rgb=hexToRgb(newcolor);
   var pocet=0.2126 * rgb.r+ 0.7152 * rgb.g + 0.0722 * rgb.b;
   
   if(pocet<128)
   document.getElementById('gh').style.color="#FFFFFF";
    else
      document.getElementById('gh').style.color="#000000";

   if (time<=0){
      window.clearInterval(lok);
      document.getElementById("gh").innerHTML="Prijímačky s už začali - veľa šťastia.";
   }
}

function doSomething(val){
   time+=val.value*3600;
}



</script>
<div align='center'>
   <h1>Tak sa začni už konečne učiť !!!!!!</h1>
   <b>Prijímačky sa konajú 8.6.2015 o </b>
   <select name="cas" onChange="doSomething(this);">
      <option selected="selected" value='-1'>8:00</option>
      <option value='1'>9:00</option>
   </select>
</b>
</div>
<div id="copyright" style='position:absolute; bottom:0;'>
    <endora></endora>
  </div>
</body>
</html>


