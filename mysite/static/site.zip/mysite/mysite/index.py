# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.template.defaulttags import register
from django.template.loader import get_template
from django.template import Context
from time import time

def notFound(request):
  return index(request,"sk","404NotFound")

def index(request,  lang="sk",page="first"):

    startTime = start = time()

    pages = [
            {"page":"first","en":"Index","sk":"Hlavná stránka"},
            {"page":"about","en":"About","sk":"O mne"},
            {"page":"study","en":"Study","sk":"Štúdium"},
            {"page":"competitions","en":"Competitions","sk":"Súťaže"},
            {"page":"camps","en":"Camps","sk":"Sústredenia"},
            {"page":"cv","en":"Cv","sk":"Cv"} ,
            ]
    
    if lang != "sk" and lang != "en":
      return notFound(request)

    found = False

    if page == "404NotFound":
      found = True

    for item in pages:
      if item["page"] == page:
        found = True
        break

    if not found:
      return notFound(request)
    
    header = get_template('index.html')
    content = get_template(page+'.html')

    translatedPages = [{"name":x[lang],"page":x["page"]} for x in pages]
    
    html = header.render(
      Context({
        "pages":translatedPages,
        "language":lang,
        "currPage":page,
        "content":content.render(
          Context({
            "language":lang
            })
        )}
      )
    )
    #html +="Page was generated in "+str((time()-startTime)*1000)+"ms."
    return HttpResponse(html)
  